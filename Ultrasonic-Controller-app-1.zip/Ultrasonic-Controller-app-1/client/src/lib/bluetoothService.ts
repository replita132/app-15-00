export class BluetoothService {
  private device: BluetoothDevice | null = null;
  private characteristic: BluetoothRemoteGATTCharacteristic | null = null;
  private mockMode = !navigator.bluetooth;

  // TODO: Replace with your device's UUIDs
  private SERVICE_UUID = '00000000-0000-0000-0000-000000000000';
  private CHARACTERISTIC_UUID = '00000000-0000-0000-0000-000000000000';

  private mockIntensity: number = 1; // Default intensity for mock mode
  private isMockRunning: boolean = false; // Indicates if mock device is running

  async connect(): Promise<boolean> {
    if (this.mockMode) {
      console.log('Mock mode: simulating connection');
      return true;
    }

    try {
      this.device = await navigator.bluetooth.requestDevice({
        filters: [{ services: [this.SERVICE_UUID] }]
      });

      const server = await this.device.gatt?.connect();
      const service = await server?.getPrimaryService(this.SERVICE_UUID);
      this.characteristic = await service?.getCharacteristic(this.CHARACTERISTIC_UUID);

      return true;
    } catch (error) {
      console.error('Bluetooth connection failed:', error);
      return false;
    }
  }

  async disconnect(): Promise<void> {
    if (this.mockMode) {
      console.log('Disconnected from mock device.');
      this.isMockRunning = false; // Stop mock device if disconnected
      return;
    }

    this.device?.gatt?.disconnect();
    this.device = null;
    this.characteristic = null;
  }

  async setIntensity(level: 1 | 2 | 3 | 4): Promise<boolean> {
    if (this.mockMode) {
      this.mockIntensity = level;
      console.log(`Mock intensity set to ${level}`);
      return true; // Simulate success
    }

    if (!this.characteristic) return false;
    try {
      await this.characteristic.writeValue(new Uint8Array([level]));
      return true;
    } catch (error) {
      console.error('Failed to set intensity:', error);
      return false;
    }
  }

  async runFor(durationMs: number): Promise<boolean> {
    if (this.mockMode) {
      this.isMockRunning = true;
      console.log(`Mock device running for ${durationMs / 1000} seconds`);
      setTimeout(() => {
        this.isMockRunning = false; // Simulate completion
        console.log('Mock device stopped running');
      }, durationMs);
      return true; // Simulate success
    }

    if (!this.characteristic) return false;
    try {
      const buffer = new ArrayBuffer(4);
      new DataView(buffer).setUint32(0, durationMs, true);
      await this.characteristic.writeValue(buffer);
      return true;
    } catch (error) {
      console.error('Failed to set duration:', error);
      return false;
    }
  }

  async stop(): Promise<boolean> {
    return this.runFor(0);
  }

  // Method to check if mock device is running
  isDeviceRunning(): boolean {
    return this.mockMode ? this.isMockRunning : this.characteristic !== null;
  }
}

export const bluetoothService = new BluetoothService();