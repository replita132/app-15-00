import React, { useState } from 'react';
import { HumidifierProvider, useHumidifier } from './context/HumidifierContext';
import { Settings } from './components/Settings';
import { StatusBar } from './components/StatusBar';


function HumidifierControls() {
  const { state, connect, disconnect, setIntensity, runFor, stop } = useHumidifier();
  const [duration, setDuration] = useState(5);
  const [theme, setTheme] = useState('light');
  const [language, setLanguage] = useState('en');
  const [scheduleTime, setScheduleTime] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const intensityLevels = [1, 2, 3, 4] as const;
  const themes = ['light', 'dark'] as const;
  const languages = ['en', 'es', 'fr', 'de'] as const;

  const handleSchedule = () => {
    if (scheduleTime) {
      const scheduledTime = new Date(scheduleTime).getTime();
      const now = new Date().getTime();
      const delay = scheduledTime - now;
      if (delay > 0) {
        setTimeout(() => runFor(duration * 60 * 1000), delay);
      }
    }
  };

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const translations = {
    en: {
      settings: 'Settings',
      theme: 'Theme',
      language: 'Language',
      schedule: 'Schedule Start',
      intensity: 'Intensity',
      duration: 'Duration',
      connect: 'Connect Device',
      start: 'Start',
      stop: 'Stop'
    },
    es: {
      settings: 'Ajustes',
      theme: 'Tema',
      language: 'Idioma',
      schedule: 'Programar Inicio',
      intensity: 'Intensidad',
      duration: 'Duración',
      connect: 'Conectar Dispositivo',
      start: 'Iniciar',
      stop: 'Detener'
    },
    fr: {
      settings: 'Paramètres',
      theme: 'Thème',
      language: 'Langue',
      schedule: 'Programmer',
      intensity: 'Intensité',
      duration: 'Durée',
      connect: 'Connecter',
      start: 'Démarrer',
      stop: 'Arrêter'
    },
    de: {
      settings: 'Einstellungen',
      theme: 'Thema',
      language: 'Sprache',
      schedule: 'Zeitplan',
      intensity: 'Intensität',
      duration: 'Dauer',
      connect: 'Verbinden',
      start: 'Start',
      stop: 'Stop'
    }
  };

  const t = translations[language as keyof typeof translations];



return (
    <div className={`min-h-screen bg-background text-foreground transition-colors duration-300 ${theme === 'dark' ? 'dark' : ''}`}>
      <StatusBar />
      <div className="max-w-md mx-auto p-6 pb-20">
        {/* Header with menu button */}
        <div className="flex justify-between items-center mb-8">
          <h1 className={`text-2xl font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            Smart Humidifier
          </h1>
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-secondary transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
            </svg>
          </button>
        </div>

        {/* Settings Menu */}
        {isMenuOpen && (
          <div className="mb-6 p-4 rounded-lg bg-card text-card-foreground shadow-lg">
            <h2 className={`text-lg font-semibold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              {t.settings}
            </h2>

            <div className="space-y-4">
              {/* Theme Selection */}
              <div>
                <label className={`block mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {t.theme}
                </label>
                <select
                  value={theme}
                  onChange={(e) => setTheme(e.target.value)}
                  className="w-full p-2 rounded-md border bg-popover text-popover-foreground hover:bg-muted focus:bg-muted outline-none shadow-sm dark:shadow-[0_2px_4px_rgba(0,0,0,0.2)]"
                >
                  {themes.map(t => (
                    <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>
                  ))}
                </select>
              </div>

              {/* Language Selection */}
              <div>
                <label className={`block mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {t.language}
                </label>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-full p-2 rounded-md border bg-popover text-popover-foreground hover:bg-muted focus:bg-muted outline-none transition-colors"
                >
                  {languages.map(l => (
                    <option key={l} value={l}>{l.toUpperCase()}</option>
                  ))}
                </select>
              </div>

              {/* Schedule Start */}
              <div>
                <label className={`block mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {t.schedule}
                </label>
                <input
                  type="datetime-local"
                  value={scheduleTime}
                  onChange={(e) => setScheduleTime(e.target.value)}
                  className="w-full p-2 rounded-md border bg-popover text-popover-foreground hover:bg-muted focus:bg-muted outline-none transition-colors"
                />
                <button
                  onClick={handleSchedule}
                  disabled={!state.isConnected || !scheduleTime}
                  className="mt-2 w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 disabled:opacity-50"
                >
                  {t.schedule}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main Controls */}
        <div className="p-6 rounded-lg bg-card text-card-foreground shadow-lg space-y-6">
          {/* Connect Button */}
          <div>
            <button 
              onClick={state.isConnected ? disconnect : connect}
              className={`w-full py-3 px-4 rounded-lg text-white font-medium transition-colors ${
                state.isConnected 
                  ? 'bg-green-500 hover:bg-green-600' 
                  : 'bg-blue-500 hover:bg-blue-600'
              }`}
            >
              {state.isConnected ? 'Connected' : t.connect}
            </button>
            {!navigator.bluetooth && (
              <p className="mt-2 text-sm text-yellow-500">
                Mock mode active - Bluetooth API not available
              </p>
            )}
          </div>

          {/* Intensity Controls */}
          <div>
            <label className={`block mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
              {t.intensity}
            </label>
            <div className="grid grid-cols-4 gap-2">
              {intensityLevels.map(level => (
                <button
                  key={level}
                  onClick={() => setIntensity(level)}
                  disabled={!state.isConnected}
                  className={`py-2 rounded-md transition-colors ${
                    state.intensity === level
                      ? 'bg-blue-500 text-white'
                      : `${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'} hover:bg-gray-200`
                  } disabled:opacity-50`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          {/* Duration Controls */}
              {/* Duration Controls */}
              <div>
                <label className={`block mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {t.duration}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    value={duration} // Use seconds directly
                    onChange={(e) => {
                      const seconds = parseInt(e.target.value) || 0;
                      setDuration(seconds); // Update state with seconds
                    }}
                    className="w-full p-2 rounded-md border bg-popover text-popover-foreground hover:bg-muted focus:bg-muted outline-none transition-colors"
                    placeholder="Seconds"
                  />
                  <span className={`absolute right-8 top-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-500'}`}>s</span>
                </div>
              </div>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  max="59"
                  value={duration % 60}
                  onChange={(e) => {
                    const minutes = parseInt(e.target.value) || 0;
                    const hours = Math.floor(duration / 60);
                    setDuration(hours * 60 + minutes);
                  }}
                  className="w-full p-2 rounded-md border bg-popover text-popover-foreground hover:bg-muted focus:bg-muted outline-none transition-colors"
                  placeholder="Minutes"
                />
                <span className={`absolute right-8 top-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-500'}`}>m</span>
              </div>
            </div>
          </div>

          {/* Start/Stop Button */}
          <button
            onClick={() => state.isRunning ? stop() : runFor(duration * 60 * 1000)}
            disabled={!state.isConnected}
            className={`w-full py-3 px-4 rounded-lg text-white font-medium transition-colors ${
              state.isRunning 
                ? 'bg-red-500 hover:bg-red-600' 
                : 'bg-green-500 hover:bg-green-600'
            } disabled:opacity-50`}
          >
            {state.isRunning ? t.stop : t.start}
          </button>

          {/* Timer Display */}
          {state.isRunning && (
            <div className={`text-center py-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              <p className="text-2xl font-semibold">
                {formatTime(state.remainingMs)}
              </p>
            </div>
          )}

          {/* Error Display */}
          {state.error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
              {state.error}
            </div>
          )}
        </div>    <

    </div>
  );
}

export default function App() {
  return (
    <HumidifierProvider>
      <HumidifierControls />
    </HumidifierProvider>
  );
}