
import React from 'react';
import { useHumidifier } from '../context/HumidifierContext';

export function StatusBar() {
  const { state } = useHumidifier();
  const { isRunning, remainingMs, scheduleTime } = state;

  if (!isRunning && !scheduleTime) return null;

  const formatTimeRemaining = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const getStatusText = () => {
    if (isRunning) {
      return `Humidifier running – ${formatTimeRemaining(remainingMs)} remaining`;
    }
    if (scheduleTime) {
      const scheduledTime = new Date(scheduleTime).getTime();
      const now = new Date().getTime();
      const timeUntilStart = scheduledTime - now;
      return `Scheduled to start in ${formatTimeRemaining(timeUntilStart)}`;
    }
    return '';
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4 shadow-lg animate-in slide-in-from-bottom">
      <div className="max-w-md mx-auto flex items-center justify-between">
        <span className="text-sm font-medium">{getStatusText()}</span>
        <button 
          className="text-muted-foreground hover:text-foreground"
          onClick={() => {/* TODO: Implement close/dismiss */}}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>
  );
}
