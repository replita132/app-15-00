
import React from 'react';
import { useHumidifier } from '../context/HumidifierContext';

type SettingsOption = 'theme' | 'language' | 'schedule';

export function Settings() {
  const [selectedOption, setSelectedOption] = React.useState<SettingsOption | null>(null);
  const { state } = useHumidifier();
  const { t, language, setLanguage, theme, setTheme, scheduleTime, setScheduleTime } = state;

  const handleBack = () => setSelectedOption(null);

  if (selectedOption === 'theme') {
    return (
      <div className="space-y-4">
        <button onClick={handleBack} className="flex items-center text-muted-foreground hover:text-foreground">
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          {t.back}
        </button>
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">{t.theme}</h3>
          <select
            value={theme}
            onChange={(e) => setTheme(e.target.value as 'light' | 'dark')}
            className="w-full p-2 rounded-md border bg-popover text-popover-foreground hover:bg-muted focus:bg-muted outline-none transition-colors"
          >
            <option value="light">Light</option>
            <option value="dark">Dark</option>
          </select>
        </div>
      </div>
    );
  }

  if (selectedOption === 'language') {
    return (
      <div className="space-y-4">
        <button onClick={handleBack} className="flex items-center text-muted-foreground hover:text-foreground">
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          {t.back}
        </button>
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">{t.language}</h3>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as 'en' | 'es' | 'fr' | 'de')}
            className="w-full p-2 rounded-md border bg-popover text-popover-foreground hover:bg-muted focus:bg-muted outline-none transition-colors"
          >
            <option value="en">English</option>
            <option value="es">Español</option>
            <option value="fr">Français</option>
            <option value="de">Deutsch</option>
          </select>
        </div>
      </div>
    );
  }

  if (selectedOption === 'schedule') {
    return (
      <div className="space-y-4">
        <button onClick={handleBack} className="flex items-center text-muted-foreground hover:text-foreground">
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          {t.back}
        </button>
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">{t.schedule}</h3>
          <input
            type="datetime-local"
            value={scheduleTime}
            onChange={(e) => setScheduleTime(e.target.value)}
            className="w-full p-2 rounded-md border bg-popover text-popover-foreground hover:bg-muted focus:bg-muted outline-none transition-colors"
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold mb-6">{t.settings}</h2>
      <div className="space-y-2">
        {[
          { id: 'theme', label: t.theme },
          { id: 'language', label: t.language },
          { id: 'schedule', label: t.schedule }
        ].map((option) => (
          <button
            key={option.id}
            onClick={() => setSelectedOption(option.id as SettingsOption)}
            className="w-full p-4 text-left rounded-lg bg-card hover:bg-muted transition-colors flex items-center justify-between"
          >
            <span>{option.label}</span>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        ))}
      </div>
    </div>
  );
}
