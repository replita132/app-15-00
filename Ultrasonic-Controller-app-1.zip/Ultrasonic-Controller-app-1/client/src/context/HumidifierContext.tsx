
import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { bluetoothService } from '../lib/bluetoothService';

type State = {
  isConnected: boolean;
  intensity: 1 | 2 | 3 | 4;
  remainingMs: number;
  isRunning: boolean;
  error: string | null;
  theme: 'light' | 'dark';
  language: 'en' | 'es' | 'fr' | 'de';
  scheduleTime: string;
  t: {
    back: string;
    settings: string;
    theme: string;
    language: string;
    schedule: string;
    [key: string]: string;
  };
};

type Action =
  | { type: 'CONNECT_SUCCESS' }
  | { type: 'CONNECT_FAILURE'; error: string }
  | { type: 'DISCONNECT' }
  | { type: 'SET_INTENSITY'; intensity: 1 | 2 | 3 | 4 }
  | { type: 'START'; durationMs: number }
  | { type: 'STOP' }
  | { type: 'TICK' };

const initialState: State = {
  isConnected: false,
  intensity: 1,
  remainingMs: 0,
  isRunning: false,
  error: null,
};

const HumidifierContext = createContext<{
  state: State;
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  setIntensity: (level: 1 | 2 | 3 | 4) => Promise<void>;
  runFor: (durationMs: number) => Promise<void>;
  stop: () => Promise<void>;
} | null>(null);

export function HumidifierProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer((state: State, action: Action): State => {
    switch (action.type) {
      case 'CONNECT_SUCCESS':
        return { ...state, isConnected: true, error: null };
      case 'CONNECT_FAILURE':
        return { ...state, isConnected: false, error: action.error };
      case 'DISCONNECT':
        return { ...state, isConnected: false };
      case 'SET_INTENSITY':
        return { ...state, intensity: action.intensity };
      case 'START':
        return { ...state, isRunning: true, remainingMs: action.durationMs };
      case 'STOP':
        return { ...state, isRunning: false, remainingMs: 0 };
      case 'TICK':
        return state.remainingMs > 0
          ? { ...state, remainingMs: state.remainingMs - 1000 }
          : { ...state, isRunning: false, remainingMs: 0 };
      default:
        return state;
    }
  }, initialState);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (state.isRunning && state.remainingMs > 0) {
      timer = setInterval(() => dispatch({ type: 'TICK' }), 1000);
    }
    return () => clearInterval(timer);
  }, [state.isRunning, state.remainingMs]);

  const connect = async () => {
    try {
      const success = await bluetoothService.connect();
      if (success) {
        dispatch({ type: 'CONNECT_SUCCESS' });
      } else {
        dispatch({ type: 'CONNECT_FAILURE', error: 'Connection failed' });
      }
    } catch (error) {
      dispatch({ type: 'CONNECT_FAILURE', error: String(error) });
    }
  };

  const disconnect = async () => {
    await bluetoothService.disconnect();
    dispatch({ type: 'DISCONNECT' });
  };

  const setIntensity = async (level: 1 | 2 | 3 | 4) => {
    const success = await bluetoothService.setIntensity(level);
    if (success) {
      dispatch({ type: 'SET_INTENSITY', intensity: level });
    }
  };

  const runFor = async (durationMs: number) => {
    const success = await bluetoothService.runFor(durationMs);
    if (success) {
      dispatch({ type: 'START', durationMs });
    }
  };

  const stop = async () => {
    const success = await bluetoothService.stop();
    if (success) {
      dispatch({ type: 'STOP' });
    }
  };

  return (
    <HumidifierContext.Provider value={{ state, connect, disconnect, setIntensity, runFor, stop }}>
      {children}
    </HumidifierContext.Provider>
  );
}

export const useHumidifier = () => {
  const context = useContext(HumidifierContext);
  if (!context) throw new Error('useHumidifier must be used within HumidifierProvider');
  return context;
};
