import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV
    });
  });

  // API endpoint for Bluetooth compatibility check
  app.get('/api/ble-compatibility', (req, res) => {
    // This is just an informational endpoint - actual compatibility checks
    // will happen on the client side with Web Bluetooth API
    res.json({
      webBluetoothSupported: true,
      message: "Web Bluetooth support must be checked in the browser",
      supportedBrowsers: [
        "Chrome (Desktop & Android)",
        "Edge (Chromium-based)",
        "Opera (Chromium-based)",
        "Samsung Internet"
      ]
    });
  });

  const httpServer = createServer(app);

  return httpServer;
}
